		// <script id="vs_kinect" type="x-shader/x-vertex">
    var vs_kinect_text = ` 
            // http://stackoverflow.com/questions/4878145/javascript-and-webgl-external-scripts
			uniform sampler2D map;
			uniform float width;
			uniform float height;
			uniform float nearClipping, farClipping;

			uniform float pointSize;
			uniform float zOffset;
            const float decodingBase = 16.0;
			varying vec2 vUv;

            const float substractionFactor = 1.6000;
            const float divisionFactor = 0.2400;
            const float xFactor = 1.3770; 
            const float yFactor = 1.1700;

            float RGBCVtoHUE(in vec3 RGB, in float C, in float V)
            {
              vec3 Delta = (V - RGB) * C;
              Delta.rgb -= Delta.brg;
              Delta.rgb += vec3(2.0,4.0,6.0);

              Delta.brg = step(V, RGB) * Delta.brg;
              float H;
              H = max(Delta.r, max(Delta.g, Delta.b));

              return fract(H / 6.0);
            }

            vec3 RGBtoHSL(in vec3 RGB)
            {
              vec3 HSL = vec3(0.0,0.0,0.0);
              float U, V;

              U = -min(RGB.r, min(RGB.g, RGB.b));
              V = max(RGB.r, max(RGB.g, RGB.b));
              HSL.z = (V - U) * 0.5;
              float C = 1.0/(V + U);
              if (C != 0.0)
              {
                HSL.x = RGBCVtoHUE(RGB, C, V);
                HSL.y = C * (1.0 - abs(2.0 * HSL.z - 1.0));
              }
              return HSL;
            }

			void main() {
				vUv = vec2( position.x / width, position.y / height );
				vec4 color = texture2D( map, vec2( (vUv.x*0.5+0.5),vUv.y ));        
        vec4 rgb_hsl = vec4((RGBtoHSL(color.rgb)),1.0);
      	if (rgb_hsl.b>0.2) {	
          float z = (((rgb_hsl.r))*(1.0/divisionFactor)+substractionFactor);
          
          vec4 pos = vec4(
          ( (position.x / width) - 0.5 ) * z * xFactor *100.0 ,
          ( (position.y /height) - 0.5 ) * z * yFactor *100.0,
          -1.0*z*100.0,
          1.0);
                                          
          gl_PointSize = pointSize;
          gl_Position = projectionMatrix * modelViewMatrix * pos;
       } 
			}
     `
	//	</script>

		//<script id="vs_noise" type="x-shader/x-vertex">
            //https://aerotwist.com/tutorials/an-introduction-to-shaders-part-2/
     var vs_noise_text =  `

            varying vec2 vUv;
            varying vec4 vColor;
            uniform sampler2D map;
            uniform sampler2D noiseMap;
            uniform float noiseScale;
            uniform float time;
            uniform float alpha;            
            void main() 
            {
                vUv = uv;

                vColor = texture2D( map, vUv);
                vColor.a = vColor.a * alpha;
                vec4 noiseColor = texture2D( noiseMap, vec2(uv.x+time*0.631,uv.y+time))-0.5;
                noiseColor.a = 0.0;
                vec4 modelViewPosition = modelViewMatrix * (vec4(position.x,position.y,position.z, 1.0)+noiseColor*noiseScale);
                gl_Position = projectionMatrix * modelViewPosition;
            }
  `            
        var fs_vertexColor_text = `
        varying vec4 vColor;
        void main() {
            gl_FragColor = vColor;
        }
        `

    var fs_kinect_text = `
            uniform sampler2D map;

            varying vec2 vUv;

            void main() {
                vec4 color = texture2D(map, vec2(vUv.x*0.5, vUv.y));
                float alpha = 0.0;
                if (color.r>0.001) alpha = 1.0;
                gl_FragColor = vec4( color.r, color.g, color.b, 1.0 );
            }
`            
