/**
 * @author mrdoob / http://mrdoob.com
 * Based on @tojiro's vr-samples-utils.js
 */

var WEBVR = {

	isLatestAvailable: function () {

		console.warn( 'WEBVR: isLatestAvailable() is being deprecated. Use .isAvailable() instead.' );
		return this.isAvailable();

	},

	isAvailable: function () {

		return navigator.getVRDisplays !== undefined;

	},

	getMessage: function () {

		var message;

		if ( navigator.getVRDisplays ) {

			navigator.getVRDisplays().then( function ( displays ) {

				if ( displays.length === 0 ) message = 'WebVR supported, but no VRDisplays found. Have you tried turning it off and on again?';

			} );

		} else {

			message = 'To enjoy this experience with VR headset, get browser with WebVR support.<br /> Find more information at <a href="http://webvr.info" target="_blank">http://webvr.info</a>.';

		}

		if ( message !== undefined ) {
            var element =  document.getElementById('ui_webvr_errorMessageBackground');
            if (typeof(element) != 'undefined' && element != null)
            {
                             element.remove();
            }
                
        	var background = document.createElement( 'div' );
            background.id = "ui_webvr_errorMessageBackground";
		
            var messageElement = document.createElement( 'div' );
            messageElement.id = "ui_webvr_messageElement";			
			messageElement.innerHTML = message;				
            
			var container = document.createElement( 'div' );
			container.id = "ui_webvr_container";

			var errorDiv = document.createElement( 'div' );
            errorDiv.classname = 'uncode_text_column';
            errorDiv.id = 'ui_webvr_errorDiv';			

            var closeButton = document.createElement( 'div' );
            closeButton.id = 'ui_webvr_close_button';

            closeButton.onclick = function(){
                container.remove();
                document.getElementById('ui_webvr_errorMessageBackground').remove();
				return false;
            };
			
            var WebVRIcon = document.createElement( 'div' );
			WebVRIcon.id = 'ui_webvr_icon';

			errorDiv.appendChild( closeButton );				
			errorDiv.appendChild( WebVRIcon );	                        
			errorDiv.appendChild( messageElement );
			container.appendChild( errorDiv );
			background.appendChild( container );
			return background;

		}

	},

	getButton: function ( effect ) {

		var button = document.createElement( 'button' );
		button.style.position = 'absolute';
		button.style.left = 'calc(50% - 50px)';
		button.style.bottom = '20px';
		button.style.width = '100px';
		button.style.border = '0';
		button.style.padding = '8px';
		button.style.cursor = 'pointer';
		button.style.backgroundColor = '#000';
		button.style.color = '#fff';
		button.style.fontFamily = 'sans-serif';
		button.style.fontSize = '13px';
		button.style.fontStyle = 'normal';
		button.style.textAlign = 'center';
		button.style.zIndex = '999';
		button.textContent = 'ENTER VR';
		button.onclick = function() {

			effect.isPresenting ? effect.exitPresent() : effect.requestPresent();

		};

		window.addEventListener( 'vrdisplaypresentchange', function ( event ) {

			button.textContent = effect.isPresenting ? 'EXIT VR' : 'ENTER VR';

		}, false );

		return button;

	}

};
