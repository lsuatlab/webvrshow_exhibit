		var container,videoContainer, divHost;
				
		var scene, camera, light, renderer;
		var cameraMobile, cameraVR, camera, centerVR;
		var geometry, cube, mesh, material;
		var mouse, center;
		var stats;
		var mixers = [];
		var video, texture;
		var effect, controlsVR, controlsMobile;
		var WebVRAvailable;
		var deviceOrientationAvailable = false;
		var developer;
		var mouseX = 0,
		mouseY = 0;
		var windowHalfX = window.innerWidth / 2;
		var windowHalfY = window.innerHeight / 2;
		var cameraY = 0, cameraX = 0, delta = 0;
	 
		console.log("Loading start");
		if (Detector.webgl) {
            document.addEventListener('mousemove', onDocumentMouseMove, false);
            window.onload = function() {
                init();
                animate();
                }
            } else {
            container.appendChild(Detector.getWebGLErrorMessage());
		}

		if (window.DeviceOrientationEvent) {
		    window.addEventListener("deviceorientation", deviceOrientationListener);
		    } else {
				
		}


		function fitToContainer(canvasElement){
				// Make it visually fill the positioned parent
				canvasElement.style.width ='100%';
				canvasElement.style.height='100%';
				// ...then set the internal size to match
				canvasElement.width  = canvasElement.offsetWidth;
				canvasElement.height = canvasElement.offsetHeight;
	   } 
		
 

		function addUIControls(parent){

				var videoElement = document.getElementById("video"); 
				var buttonsDiv = document.createElement('div');
				buttonsDiv.id = "ui_buttons_dust3D";
				buttonsDiv.className = "vc-dust-ui-buttons";
				
				//https://developers.facebook.com/docs/sharing/best-practices

				buttonFacebook = document.createElement('div');
				buttonFacebook.id = "ui_button_facebook";
				buttonFacebook.title = "Share with your friends via Facebook";
				buttonFacebook.className = "vc-dust-ui-button";
				//buttonsDiv.appendChild(buttonFacebook);
				buttonFacebook.onclick = function(){

								FB.ui({
										method: 'share',
										href: window.location.href,
									  }, function(response){});
								return false;
								};
					
				buttonTwitter = document.createElement('div');
				buttonTwitter.id = "ui_button_twitter";
				buttonTwitter.title = "Share with your friends via Twitter";				
				buttonTwitter.className = "vc-dust-ui-button";
				buttonTwitter.onclick = function(){
												tweetCurrentPage();
												return false;
				};

				//buttonsDiv.appendChild(buttonTwitter);

				buttonWebVR = document.createElement('div');
				buttonWebVR.id = "ui_button_webvr";
				buttonWebVR.className = "vc-dust-ui-button";
				buttonWebVR.title = "View in WebVR";
				buttonWebVR.onclick = function(){
						var webVRMessage = document.getElementById("ui_webvr_errorMessageBackground");

						if (WEBVR.isAvailable() === false) {
										if (webVRMessage) {
												webVRMessage.remove();

										} else {	
												container.appendChild(WEBVR.getMessage());
										}
						} else {
								effect.isPresenting ? effect.exitPresent() : effect.requestPresent();
						}
						
					
						return false;	


				}
				Window.onvrdisplaypresentchange = function() {
						
				}
			
				buttonsDiv.appendChild(buttonWebVR);

				if (screenfull.enabled) {
						buttonFullscreen = document.createElement('div');
						buttonFullscreen.id = "ui_button_fullscreen";
						buttonFullscreen.className = "vc-dust-ui-button";
						buttonFullscreen.title = "View in fullscreen (Enter)";
						buttonsDiv.appendChild(buttonFullscreen);
						buttonFullscreen.onclick = function() {
								screenfull.toggle(container);
								
								
								fitToContainer(container);


								
								return false;
					}
				}

				buttonMute = document.createElement('div');
				buttonMute.id = "ui_button_mute";
				buttonMute.className = "vc-dust-ui-button";
				buttonMute.onclick = function(){
						if(videoElement.muted) {
								videoElement.muted = false;
						} else {
								videoElement.muted = true;
						}
						return false;
				}
				//Not available yet, no soundtrack
				buttonsDiv.appendChild(buttonMute);				
				
				buttonPlay = document.createElement('div');
				buttonPlay.id = "ui_button_play";
				buttonPlay.className = "vc-dust-ui-button";
				buttonPlay.onclick = function(){
						if(videoElement.paused) {
								videoElement.play();

						} else {
								videoElement.pause();
						}
						
						return false;
				}
				buttonsDiv.appendChild(buttonPlay);
				
				videoElement.onpause= function(){
						buttonPlay.title = "Play";
						buttonPlay.style.backgroundImage  = 'url("includes/ui_buttons/ui_button_play.svg")';
						return false;
				}
				videoElement.onplay= function(){
						buttonPlay.title = "Pause";
						buttonPlay.style.backgroundImage  = 'url("includes/ui_buttons/ui_button_play_not.svg")';
						
						if (typeof videoElement.onvolumechange == "function") {
								videoElement.onvolumechange.apply(videoElement);
						}
						
						return false;
				}
								
				videoElement.onvolumechange = function() {
						if (videoElement.muted) {
								//Not available yet, no soundtrack								
								buttonMute.title = "Unmute";
								buttonMute.style.backgroundImage  = 'url("includes/ui_buttons/ui_button_mute.svg")';
						} else {
								buttonMute.title = "Mute";
								buttonMute.style.backgroundImage  = 'url("includes/ui_buttons/ui_button_mute_not.svg")';								
						}
						return false;						
				}
				videoElement.onplay = function () {
				    console.log("loop");
				    return false;
				}

				parent.appendChild(buttonsDiv);						
		};
		
		window.addEventListener( 'vrdisplaypresentchange', function ( event ) {
				var buttonWebVR = document.getElementById("ui_button_webvr");
				buttonWebVR.title = effect.isPresenting ? 'Exit WebVR' : 'View in WebVR';
				if (effect.isPresenting) {			
						buttonWebVR.title = "View in WebVR";
						buttonWebVR.style.backgroundImage  = 'url("includes/ui_buttons/ui_button_webvr.svg")';					
				} else {

						buttonWebVR.title = "Exit WebVR";
						buttonWebVR.style.backgroundImage  = 'url("includes/ui_buttons/ui_button_webvr_not.svg")';							
				}
		}, false );		
		
		function iOSversion() {		
		  if (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream) {
			if (!!window.indexedDB) { return 'iOS 8 and up'; }
			if (!!window.SpeechSynthesisUtterance) { return 'iOS 7'; }
			if (!!window.webkitAudioContext) { return 'iOS 6'; }
			if (!!window.matchMedia) { return 'iOS 5'; }
			if (!!window.history && 'pushState' in window.history) { return 'iOS 4'; }
			return 'iOS 3 or earlier';
		  }
		
		  return 'Not an iOS device';
		}
		function deviceOrientationListener(event) {
				if (event.beta != null) {
						deviceOrientationAvailable = true;
				}	
		}
			  
			function callbackModel( geometry, s, material, x, y, z, rx, ry ) {
				var mesh = new THREE.Mesh( geometry, material );
				mesh.position.set( x, y, z );
				mesh.scale.set( s, s, s );
				mesh.rotation.x = rx;
				mesh.rotation.z = ry;
				mesh.castShadow = false;
				mesh.receiveShadow = false;
				scene.add( mesh );
			}

			function init() {

			  // <video id="video" autoplay="" loop="" muted="" playsinline="" src="textures/kinect2.mp4" style="display:none">

			  container = document.createElement('div');
			  videoContainer = document.createElement('div');

			  videoContainer.innerHTML += `
      <video id="video"   autoplay="" muted loop="" playsinline  preload="metadata" webkit-playsinline="" style="display:none">
			     <source src="includes/textures/kinect2.mp4" type="video/mp4; codecs=&quot;avc1.42E01E, mp4a.40.2&quot;">
			     <source src="includes/textures/kinect2.ogv" type="video/ogg; codecs=&quot;theora, vorbis&quot;">
		    </video>`
			//https://www.w3.org/2010/05/video/mediaevents.html


			  renderer = new THREE.WebGLRenderer({
			    antialias: true
			  });
			  renderer.setPixelRatio(window.devicePixelRatio);
			  renderer.setSize(window.innerWidth, window.innerHeight);
			  renderer.sortObjects = false;


			  divHost = document.getElementById("dust");
			
			  divHost.appendChild(videoContainer);
			  divHost.appendChild(container);

				renderer.domElement.id = "canvas_dust3d";
			  container.appendChild(renderer.domElement);

				document.addEventListener("keydown", function(e) {
				 if (e.keyCode == 13) {
					if (screenfull.enabled) {
						screenfull.toggle(renderer.domElement);
					}

				 }
				}, false);
				
     //https://webkit.org/blog/6784/new-video-policies-for-ios/
			  var video = document.querySelector('video');
			  enableInlineVideo(video);
				addUIControls(container);				

				
				video.oncanplay = function() {

										setTimeout(function() {
												video.play();
												if (iOSversion()=='Not an iOS device')
												{
													video.muted = false;
												} else {};
										}, 2000);
				};
				

			  this.clock = new THREE.Clock();

			    // model
			  console.log("Loading");
			  var manager = new THREE.LoadingManager();
			  manager.onProgress = function(item, loaded, total) {
			    console.log("Loading2");
			    console.log(item, loaded, total);

			  };
			  var onProgress = function(xhr) {
			    console.log("Loading");
			    if (xhr.lengthComputable) {

			        var percentComplete = xhr.loaded / xhr.total * 100;
			        console.log("Loading", percentComplete);
			    }

			  };
			  var onError = function(xhr) {

			    console.error(xhr);

			  };



				var loader = new THREE.TextureLoader();
				
				camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.001, 10000);
				camera.position.set(0.5, 0.5, 2);
				center = new THREE.Vector3();
				
				cameraVR = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.001, 10000);
				cameraVR.position.set(0.05, 0.05, 0.2);
				centerVR = new THREE.Vector3();
				
				cameraMobile = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.001, 10000);
				cameraMobileInverted = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.01, 10000);
				cameraMobile.position.set(1.0, 1.0, -8.0);
				cameraMobile.lookAt( -1.0, -1.0, 5.0 );
			  

				
				scene = new THREE.Scene();
        
                var grid = new THREE.GridHelper(20, 40);
                //scene.add(grid);
        				
				//Lights
				var ambient = new THREE.AmbientLight(0x050505);
				scene.add(ambient);
				var directionalLight = new THREE.DirectionalLight(0x666666);
				directionalLight.position.set(0, 0, 1);
				scene.add(directionalLight);

				//Skydome
				var skyGeo = new THREE.SphereGeometry(9000, 25, 25);
				var texture = loader.load("./includes/textures/skydome_gradient.jpg");
				texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
				texture.repeat.set( 50, 1 );
				var material = new THREE.MeshBasicMaterial({
						map: texture,
				});
				var sky = new THREE.Mesh(skyGeo, material);
				sky.material.side = THREE.BackSide;
				scene.add(sky);

				var manager = new THREE.LoadingManager();
				manager.onProgress = function(item, loaded, total) {
					console.log(item, loaded, total);
			  };
			  var texture = new THREE.Texture();
			  var onProgress = function (xhr) {
			      console.log("load");
			    if (xhr.lengthComputable) {
			      var percentComplete = xhr.loaded / xhr.total * 100;
			      console.log(Math.round(percentComplete, 2) + '% downloaded');
			    }
			  };
			  var onError = function(xhr) {};

			  // model
			  this.buildingShaderUniforms = {
			    map: {
			      type: "t",
			      value: loader.load("./includes/models/obj/1stF_studio_marie_rambert_M1_desaturated_small.png")
			    },
			    noiseMap: {
			      type: "t",
			      value: loader.load("./includes/textures/waternormals.jpg")
			    },
			    noiseScale: {
			      type: "f",
			      value: 0.001
			    },
			    time: {
			      type: "f",
			      value: 0.0
			    },
			    alpha: {
			      type: "f",
			      value: 0.7
			    }
			  };
			  buildingShaderUniforms.noiseMap.value.wrapS = buildingShaderUniforms.noiseMap.value.wrapT = THREE.RepeatWrapping;
			  var material3 = new THREE.ShaderMaterial({
			    vertexShader: vs_noise_text,
			    fragmentShader: fs_vertexColor_text,
			    uniforms: buildingShaderUniforms,
			    wireframe: true,
			    blending: THREE.NormalBlending,
			    transparent: true

			  });

				var loaderCTM = new THREE.CTMLoader();

			  loaderCTM.load( "./includes/models/ctm/marie-rambert-studio.ctm",  function( object ) {

					callbackModel( object, 1100, material3, 10.0, -11.2, 0, 0, 0 );
			  }, onProgress, onError);


			  video = document.getElementById('video');

			  texture = new THREE.VideoTexture(video);
			  texture.format = THREE.RGBFormat;


			  texture = new THREE.VideoTexture(video);
			  texture.minFilter = THREE.NearestFilter;
			  texture.magFilter = THREE.NearestFilter;

			  var width = 512,
			    height = 424;

			  var nearClipping = 1,
			    farClipping = 4000;

			  geometry = new THREE.BufferGeometry();

			  var vertices = new Float32Array(width * height * 3);

			  for (var i = 0, j = 0, l = vertices.length; i < l; i += 3, j++) {
			    //vertices[i] = j % width + Math.random();
			    //vertices[i + 1] = Math.floor(j / width) + Math.random();
			    vertices[i] = j % width;
			    vertices[i + 1] = Math.floor(j / width);

			  }

			  geometry.addAttribute('position', new THREE.BufferAttribute(vertices, 3));



			  material = new THREE.ShaderMaterial({

			    uniforms: {
			      "map": {
			        value: texture
			      },
			      "width": {
			        value: width
			      },
			      "height": {
			        value: height
			      },

			      "pointSize": {
			        value: 2
			      },
			      "zOffset": {
			        value: 1000
			      },
			      "xFactor": {
			        value: 1.3770
			      },
			      "yFactor": {
			        value: 1.1700
			      },
			    },
			    vertexShader: vs_kinect_text,
			    fragmentShader: fs_kinect_text,
			    blending: THREE.NormalBlending,
			    depthTest: true,
			    depthWrite: true,
			    transparent: true
			  });

			  mesh = new THREE.Points(geometry, material);
			  //dancer position
			  mesh.position.x = -0.2;
			  mesh.position.y = -0.5;
			  mesh.position.z = 0.35;
        mesh.scale.x = 0.01;
        mesh.scale.y = 0.01;
        mesh.scale.z = 0.01;        
			  scene.add(mesh);


				controlsMobile = new THREE.DeviceOrientationControls( cameraMobile, true );
				var testOrientationvector = new THREE.Vector3(0,1,1);
				//controlsMobile2 = new THREE.DeviceOrientationControls(testOrientationvector , true );

				controlsVR = new THREE.VRControls(cameraVR);
				
			  effect = new THREE.VREffect(renderer);

			  if (navigator.getVRDisplays) {

			    navigator.getVRDisplays()
			      .then(function(displays) {
			        effect.setVRDisplay(displays[0]);
			        controlsVR.setVRDisplay(displays[0]);
			      })
			      .catch(function() {
			        // no displays
			      });

			    //document.body.appendChild(WEBVR.getButton(effect));
			  }
			  window.addEventListener('resize', onWindowResize, false);
			  console.log("Loading done");
			}

			function onWindowResize() {
				camera.aspect = window.innerWidth / window.innerHeight;
				camera.updateProjectionMatrix();
				
				cameraMobileInverted.aspect = window.innerWidth / window.innerHeight;
				cameraMobileInverted.updateProjectionMatrix();				

				effect.setSize(window.innerWidth, window.innerHeight);
				console.log("window resize");
								
				if (screenfull.isFullscreen) {
						//Not available yet, no soundtrack								
						buttonFullscreen.title = "Exit Fullscreen";
						buttonFullscreen.style.backgroundImage  = 'url("includes/ui_buttons/ui_button_fullscreen_not.svg")';
				} else {
						buttonFullscreen.title = "Fullscreen";
						buttonFullscreen.style.backgroundImage  = 'url("includes/ui_buttons/ui_button_fullscreen.svg")';								
				}
				
				return false;									
			}



			function animate() {
				effect.requestAnimationFrame( animate );
				render();
			}

			function lerp(a, b, t) {
				var x = a + t * (b - a);
				return x;
			}

			function onDocumentMouseMove(event) {
			  mouseX = (event.clientX - windowHalfX);
			  mouseY = (event.clientY - windowHalfY);
			}


			function render() {
				
				

				if (effect.isPresenting)
				{
						controlsVR.update();
						effect.render( scene, cameraVR );	
				} else
				{
					if (deviceOrientationAvailable) {


								controlsMobile.update();
								var vectorx = new THREE.Vector3();
								cameraMobile.getWorldDirection( vectorx );
																
								cameraMobileInverted.position.x = vectorx.x*0.4;
								cameraMobileInverted.position.y = vectorx.y*-0.4;
								cameraMobileInverted.position.z = vectorx.z*0.4;								
								cameraMobileInverted.lookAt(center);								
								effect.render( scene, cameraMobileInverted );							
						} else {
								delta = cameraX;
								
								cameraX = lerp(cameraX, mouseX*0.01, 0.004);
								cameraY = lerp(cameraY, mouseY*0.01, 0.0025);
								delta = 0.0003 - Math.min(0.0003, (cameraX - delta) * 0.00003);
								buildingShaderUniforms.time.value += delta * 0.1;
								
								camera.position.x += (cameraX - camera.position.x) * 0.005;
								camera.position.y += (-cameraY - camera.position.y) * 0.003;
								center.x = cameraX * 0.00015;
								center.y = cameraY * 0.00012;
								
								camera.lookAt(center);
								
								controlsVR.update();
								
								effect.render( scene, camera );
						};
				};		  
		}
